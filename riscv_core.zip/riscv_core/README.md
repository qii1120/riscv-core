This is a simple pipeline riscv core.
Here is result that my core run coremark.
![image](https://github.com/qii1120/School-Work/assets/87166290/56fb69d2-6afb-45a8-95bd-44c64b3b1b5c)
