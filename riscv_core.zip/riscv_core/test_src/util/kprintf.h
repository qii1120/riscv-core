
#ifndef _XPRINTF_H_
#define _XPRINTF_H_

int put_char (char c);
int put_str (const char* str);
void kprintf (const char* fmt, ...);

#endif